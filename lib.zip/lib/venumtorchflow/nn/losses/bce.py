import numpy as np
import nnfs

nnfs.init()

